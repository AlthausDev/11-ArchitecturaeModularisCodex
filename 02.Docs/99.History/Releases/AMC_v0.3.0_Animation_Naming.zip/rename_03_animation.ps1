# rename_03_animation.ps1
# Ejecuta este script dentro de la carpeta 'mods' de tu perfil MO2.
# Sustituye las claves de la izquierda por tus nombres actuales.

$map = @{
    # --- Frameworks ---
    "True Directional Movement" = "03.01-Animation-Frameworks-TDM"
    "MCO Universal Support"     = "03.01-Animation-Frameworks-MCOUniversalSupport"

    # --- Combat ---
    "Attack - MCO DXP"          = "03.02-Animation-Combat-AttackMCO_DXP"
    "Dodge - MCO DXP"           = "03.02-Animation-Combat-DodgeMCO_DXP"
    "Movement - MCO DXP"        = "03.02-Animation-Combat-MovementMCO_DXP"
    "Valhalla Combat"           = "03.02-Animation-Combat-ValhallaCombat"

    # --- Locomotion ---
    "EVG Conditional Idles"     = "03.03-Animation-Locomotion-EVGConditionalIdles"
    "EVG Animation Variance"    = "03.03-Animation-Locomotion-EVGAnimationVariance"
    "SmoothCam"                 = "03.03-Animation-Locomotion-SmoothCam"

    # --- Nemesis output (si lo mantienes como mod separado) ---
    "Nemesis Output"            = "03.01-Animation-Frameworks-NemesisOutput"
}

foreach ($old in $map.Keys) {
    $new = $map[$old]
    if (Test-Path $old) {
        Write-Host "Renombrando '$old' -> '$new'"
        Rename-Item -Path $old -NewName $new -Force
    } else {
        Write-Host "No encontrado: $old (omite si ya estaba renombrado)"
    }
}
Write-Host "Listo."

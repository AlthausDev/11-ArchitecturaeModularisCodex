AMC v0.5.1 – Doctrine Aesthetica + World Enrichment
Includes DoctrineAesthetica.md
# 🕯️ Doctrine Aesthetica — Harmonía, Crudeza y Plenitud

## I. Forma y espíritu
“La belleza no es suavidad, es precisión bajo tensión.”

El AMC no es un conjunto de mods: es una arquitectura simbólica. 
Cada textura, animación o línea de código tiene un lugar, un propósito y una resonancia. 
Nada es gratuito; todo debe respirar el mismo tono: sobriedad, armonía y crudeza elegante.

## II. Romanticismo técnico
- El color es lenguaje. Prefiere piedra, mármol, bronce, ceniza, sangre contenida.  
- La luz no decora: revela. Lo visible debe ser apenas una sugerencia.  
- La brutalidad no es un recurso: es memoria física de la existencia.  
- El erotismo, cuando aparece, es una confesión, no una exposición.  
- El silencio, la pausa y la sombra tienen el mismo valor que la acción.  

## III. Universum: Riqueza y consecuencia
“Todo puede existir, pero todo debe tener consecuencia.”

El mundo AMC es pleno, pero no caótico.  
Cada elemento —sea ruina, dios, criatura o ritual— existe porque explica algo del universo.

### Capas del mundo
| Capa | Naturaleza | Ejemplo AMC |
|------|-------------|-------------|
| Visible | Ciudades, paisajes, texturas | Bloques 04–07 |
| Latente | Lore, misiones, ruinas, reliquias | Bloques 08–10 |
| Oculta | Erotismo, rito, brutalidad, deseo | Bloque 11 |
| Estructural | Scripts, dependencias, LODs, merges | Bloques 00–03, 12–14 |

Regla: Riqueza ≠ Caos.  
Cada adición debe tener un porqué estético, simbólico o técnico.

## IV. El bloque 11 y la amplitud controlada
“El cuerpo puede hablar, pero dentro de la arquitectura del mundo.”

El bloque 11.Adult representa la pulsión, la carne y el riesgo.  
Su libertad es total, pero contenida por forma y tono.

### Subbloques AMC 11 sugeridos
11.01-Adult-Frameworks  
11.02-Adult-Animations  
11.03-Adult-Creatures  
11.04-Adult-NPCs  
11.05-Adult-RitualsAndMagic  
11.06-Adult-Visuals  
11.07-Adult-Audio

### Normas
- El erotismo debe tener propósito narrativo o simbólico.  
- La sangre y la muerte son parte del lenguaje estético, no del espectáculo.  
- Ningún acto es gratuito: todo tiene eco.  

## V. Romanticum — La tríada de la sombra y el fuego
“La razón sostiene la forma, la emoción la ilumina, el deseo la destruye, y de esa ruina nace lo bello.”

### Poe — El abismo íntimo
- El dolor y la muerte son la forma más pura de belleza.  
- La oscuridad debe sentirse, no explicarse.  
- El silencio y la obsesión son texturas.

### Goethe — El conocimiento como condena
- La magia y la ciencia son un mismo acto de búsqueda.  
- Cada hechizo, artefacto o ruina es un fragmento de Fausto.  
- La perfección cuesta el alma.

### Byron — La rebeldía consciente
- La libertad no es júbilo, es soledad elegida.  
- El héroe AMC no busca salvación: busca verdad.  
- El amor y el deseo son armas de autodestrucción hermosa.

### Síntesis AMC
| Pilar | Símbolo | En el mundo AMC |
|--------|----------|----------------|
| Poe | La rosa marchita | Belleza del dolor y del silencio |
| Goethe | El laboratorio encendido | Sabiduría como ascenso y caída |
| Byron | El exilio voluntario | Libertad como ruina lúcida |

## VI. Conclusión
“El orden sostiene la forma, pero la forma contiene el alma.  
El alma, cuando arde, es el único artificio que no necesita artificio.”

— Architecturae Modularis Codex  
Doctrine Aesthetica v1.0 — Harmonía, Crudeza y Plenitud

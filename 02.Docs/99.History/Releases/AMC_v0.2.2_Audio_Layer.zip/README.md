# AMC v0.2.2 — Audio Layer

**Estado:** ✅ Estable (bajo riesgo)  
**Ubicación:** `05.Audio`  
**Dependencias:** 00.Core (nada especial), 01.Frameworks (ninguna directa)  
**Objetivo:** Mejorar presencia sonora sin tocar gameplay ni scripts persistentes.

> Diseño: **ligero y seguro**. Se prioriza compatibilidad AE y mínima necesidad de parches.

---

## ⚙️ Estructura

```
05.Audio
│
├─ 05.02-Audio-Ambience
│   ├─ Reverb and Ambience Overhaul (RAO)
│   └─ Cathedral - 3D Sound Project
│
├─ 05.03-Audio-SFX
│   └─ Audio Overhaul for Skyrim (AOS)
│
└─ 05.07-Audio-UI
    └─ Immersive UI Sounds (opcional)
```

> Nota: **AOS** y **ISC (Immersive Sounds - Compendium)** pueden convivir con parches, pero para mantener este bloque rápido y sin fricción se recomienda **usar AOS solo**. Si más adelante quieres añadir ISC, lo haremos junto a su *Patch Hub* en `12.Patches`.

---

## 🧩 Tabla de componentes

| Categoría | Mod | Nombre AMC | Descripción | Enlace |
|---|---|---|---|---|
| Ambience | Reverb and Ambience Overhaul | 05.02-Audio-Ambience-RAO | Reverb realista y espaciosidad interior/exterior. | https://www.nexusmods.com/skyrimspecialedition/mods/701 |
| Ambience | Cathedral - 3D Sound Project | 05.02-Audio-Ambience-Cathedral3DSound | Posicionamiento y espacialización 3D mejorada. | https://www.nexusmods.com/skyrimspecialedition/mods/17739 |
| SFX | Audio Overhaul for Skyrim SE | 05.03-Audio-SFX-AOS | Reequilibra y mejora miles de efectos (armas, magia, ambiente). | https://www.nexusmods.com/skyrimspecialedition/mods/12466 |
| UI (opcional) | Immersive UI Sounds | 05.07-Audio-UI-ImmersiveUISounds | Sonidos de interfaz sutiles y modernos. | https://www.nexusmods.com/skyrimspecialedition/mods/84357 |

---

## 🔧 Orden recomendado (MO2)

```
05.02-Audio-Ambience-RAO
05.02-Audio-Ambience-Cathedral3DSound
05.03-Audio-SFX-AOS
05.07-Audio-UI-ImmersiveUISounds (opcional)
```

- Cargar **RAO** antes que **AOS** es indiferente; el orden de arriba favorece que AOS sobrescriba SFX cuando corresponda.
- **No** requiere Nemesis, SPID ni parches inmediatos.
- Compatible con Interface (06) y con futuros Visual (04).

---

## 📜 Notas y futuras ampliaciones

- Añadir **ISC** más adelante (si lo deseas) con su *AOS + ISC Patch* en `12.04-Patches-ConflictResolutions`.
- Para música: se sugiere diferir hasta elegir estética (bloque 04.Visual). Ej.: *Fantasy Soundtrack Project* o *Immersive Music*.
- Si usas ENB y audio HRTF externo, prueba primero Cathedral 3D; si notas ecos indeseados, baja su volumen en el *Audio Settings*.


## 🧾 Changelog AMC v0.2.2

```
[+] Added base Audio Layer: RAO + Cathedral 3D + AOS
[+] Optional: Immersive UI Sounds
[*] Zero script footprint, AE-safe
```

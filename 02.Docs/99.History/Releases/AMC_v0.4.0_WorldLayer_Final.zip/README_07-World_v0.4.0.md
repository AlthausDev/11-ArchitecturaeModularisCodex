# 🌍 AMC v0.4.0 — World Layer (Final)

Bloque que consolida toda la capa de entorno físico y geográfico de Skyrim AE:
ciudades, aldeas, terrenos, flora, agua, iluminación ambiental y expansiones.

## 🧱 Estructura AMC
- 07.01 Overhauls: Dawn of Skyrim, Great Cities AIO
- 07.02 Cities: Riften Docks, Whiterun Outskirts
- 07.04 Villages: Riverwood
- 07.05 Dungeons: Ruins Clutter Improved, Embers XD
- 07.07 Landscapes: Cathedral Landscapes, Nordic Snow (opcional), Water for ENB
- 07.08 Flora: Cathedral Flora + Happy Little Trees
- 07.09 Lighting: Lanterns of Skyrim II
- 07.10 Clutter: Glorious Doors, Forgotten Retex
- 07.12 NewWorld: Falskaar, Wyrmstooth (+Castellano, Hearthfire, Dragonborn)
- 07.13 MapLOD: DynDOLOD3 (pendiente generación final)

## 🔧 Recomendaciones
- Desactivar Water for ENB hasta integrar ENB y luces (Bloque 04).
- No generar DynDOLOD hasta cerrar 04.Visual.
- Nordic Snow es opcional; reemplaza texturas de nieve Cathedral.
- SFO descartado para evitar conflicto con HLT + Cathedral Flora.

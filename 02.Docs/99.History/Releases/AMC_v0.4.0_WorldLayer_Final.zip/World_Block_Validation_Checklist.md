# ✅ Checklist de validación — Bloque 07.World

☐ Revisar blending caminos/terreno (Blended Roads)
☐ Verificar coherencia entre HLT y Cathedral Flora
☐ Comprobar luces nocturnas (Lanterns of Skyrim II)
☐ Confirmar traducciones Castellano activas
☐ Orden: Overhauls → Cities → Villages → Dungeons → Landscapes → Flora → Lighting → Clutter → NewWorld → MapLOD
☐ Guardar save limpio para pruebas del bloque 04.Visual

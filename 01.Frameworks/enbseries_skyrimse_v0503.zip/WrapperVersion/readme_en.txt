//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//ENBSeries is a set of graphical modifications for games
//Description on the web page may not be equal to this info.
//created by Boris Vorontsov http://enbdev.com
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

PUBLISHING BINARY FILES OF ENBSERIES ON NEXUS SITES (FALLOUT NEXUS, TES NEXUS, ETC)
IS STRICTLY PROHIBITED. ONLY PRESETS AND SHADERS CAN BE HOSTED THERE.



ENBSeries v0.503 for TES Skyrim SE.

Added boolean parameters HDRWeighting for each color filter to compute them with intensity,
this allow to make short moments like red sunrise and sunset.
Fixed wet surfaces from first person models which were broken several last versions.
Fixed dark eyes in enblite mode.
Added [OBJECTGLOW] category which is editable for objects with their glow map alpha channel
set to black, as solution against window lights influence mushrooms and some other objects.
Added soul caim setting of sky as aurora. Removed tiling of water lod.
Added partial compatibility with mods which modify path of the sun.
Fixed bug of wet surfaces when entering interiors if dynamic cubemaps disabled.
Increased x4 times resolution of dynamic cubemaps.
Added FixBlackCrush parameter to the [SKY] category, which eliminates game bug.
Some weather mods and presets at certain weathers at the night may not have correct sky
appearance with FixBlackCrush enabled, because they are tweaked to match buggy sky.
Do not turn on this feature, unless you make preset for really dark HDR nights.
Fixed rare bug with clouds scattering when temporal antialiasing is enabled.
Fixed green transparent objects in reflections (previously was fixed for hairs only).
Fixed bright night sky in reflections when using mods which modify camera distance.
Changed dynamic cubemap so it can reflect more objects. Increased number of lights
which grass can use. Disabled terrain blending when LinuxVersion=true set.
Added [MEMBRANE] category for ghosts and actors with debuffs or other similar effects.
Added particles around ghost to the [PARTICLE] category. Reduced flash of adaptation
when game window is not active. Fixed volumetric rays intensity at near zero levels.
Added fix of noise when subsurface scattering and ambient occlusion enabled both.
Added UseProceduralGradientWeights and ProceduralGradientWeightCurve to the [SKY]
category to make banding free sky gradient and ignore middle sky properties.
Applying modified shaders to inventory items.
Added static cubemap for inventory items which use complex material. It can be
replaced by custom enbcubemapinventory.dds file.
Added support of Terrain Helper skse mod which allow to attach extra 6 parallax textures
for terrain to resolve alpha blending issues of non terrain meshes like dirt cliffs and
for performance benefits.
Changed how Terrain Helper skse mod is handled, now if texture slot of it is not added,
parallax switches back to using alpha channel of diffuse texture. Added workaround of
rare flickering complex grass from lighting caused by unknown game bug which spawns
extra light in one frame. Improved distant water lod.
Expanded range of Power and PowerInterior parameters under [REFLECTION] category to allow
original game visuals of ssr effect.
Fixed bug in the original post processing of enbeffect.fx shader, but it do not influence
almost all existing presets.
Fixed bug of curve parameter for [OBJECTGLOW] category.
Added FixWaterBlendingToSky parameter to the enblocal.ini.


For multiple weather system and some other features you need enbhelperse.dll SKSE plugin,
download it here https://www.nexusmods.com/skyrimspecialedition/mods/23174/

WARNING! For compatibility with some other software (i call it crapware) read "problems"
category of this document, it's very important to not have any other tools hooking in to
game process or graphics. Crashes, graphic artifacts after installing ENB mods/patches
almost always means crapware is running.

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//CHANGES LOG
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Version 0.502
Added curve parameter for moons. Added CloudsVertexAlphaBoost for [SKY] category.
Added [SKYSCATTERING] category to improve game sky system. Added EnableCloudsScattering
parameter and lighting effect for game clouds. Added fix for thumbnails of saved games.
Fixed bug of flickering lights when terrain blending and detailed shadows enabled both.
Added moon rays effect and new parameters of it in the [RAYS] category.
Restored emissive control over particle lights so they can change with time of the day
with proper flags set. This was removed several versions back with optimizations.
Added ShadowHardness parameters to the complex parallax.

Version 0.499
Former Patreon optimized version with some adjustments.
Added fog to water reflections. Decreased time to apply changes in editor for
cpu with more than 6 cores. Fixed distant shadows for lod trees.
Fixed bug of indirect lighting when sun or sky intensity is huge. Fixed bug of the
game volumetric rays when big values of their intensity makes picture darker.
Fixed clouds transparency for clouds shadows and sun rays, which didn't work correct
when several clouds layers mixed. Reduced glitches of ambient occlusion which appeared
after optimization last year. Limited amount and intensity of ambient occlusion to not
allow absurdly high levels of them. Little bit sorted categories to make more sense in
their order. Fixed lag from water when cells loading.
Increased limit of sun glare intensity and il compression. Changed how detailed shadows
applied to the complex grass to have subsurface scattering more visible.
Applied dynamic cubemap for wetness effect to reduce some bugs.
Added LinuxVersion parameter to enblocal.ini and removed separate version for this OS.

Version 0.494
Ported optimizations and quality improvements from Patreon version for rain, water,
underwater, sky, shadow and various minor cpu optimizations. Tweaked complex parallax a bit.
Disabled parallax shadow for objects with back lighting flag to avoid visual artifacts.
Added complex material to non specular meshes to fix visual bugs with lod switching by distance.
Added dynamic cubemaps which activated for objects with 1px size cubemaps. Very useful to make
reflective surfaces more realistic, including metallic of complex material. New parameter
ApplyDynamicCubemapEverywhere in the editor window is not stored in the enbseries.ini for
compatibility with mods which strongly require static cubemaps, so if you need this effect,
activate parameter ApplyDynamicCubemapEverywhere every time.
Added EnableDynamicCubemap parameter to toggle effect globally. Fixed bug with non updating
exterior cubemap when forced dynamic cubemap everywhere parameter is disabled.
Fixed overly bright dynamic cubemaps, which was caused by math of static cubemaps.
Added reflection parameters to the [EYE] category and applied dynamic cubemaps to eyes.
Added skylighting influence on dynamic cubemaps and default cubemap texture as modders resource.
Adjusted clouds shadows to make them visible in reflections at bigger distances.
Added default parameter support of dropdown menu item.
Improved detection of WindowLight to stop spell decals from glowing.

Version 0.493
Ported optimized complex parallax from Patreon version. Added PointLightingInfluence to the [PARTICLE].

Version 0.488
Fixed various bugs with water and made sharper looking displacement. Other minor bug fixes
for water. Changed screenshots location to "screenshots" folder instead of game root.
Decreased startup time as part of global optimization in progress. Added properly
casted caustics on the water bottom from character waves. Removed static decals as no mod
released with them and game have bug for them which i fixed, but that fix made dynamic decals
not work properly (as they do not have game bug), such as footprints and hits from spells.
Added workaround for reported black dots on bodies, maybe caused by some mod or driver bug.
Fixed crash with complex grass enabled for some AMD users. Fixed noisy shadows for AMD users.
Fixed underwater caustics not applied properly with some mods which change sky mesh.
Fixed stuttering issue caused by power management of some videocards.
Improved quality of subsurface scattering effect. Removed quality parameter of subsurface
scattering as it was not used for long.
Fixed some vanilla hairs for image based lighting and particle lighting when using specular.
Fixed compatibility with NAT sky mesh which incorrectly worked with particle lights.
Added UseLinearMath to the [RAYS] category to make sun rays work properly with high sun intensities.

Version 0.484
Added [COMPLEXMATERIAL] category and support of dielectric and metallic materials.
Complex material type also allow to use parallax on it. Details about implementation
you can ask on the forum or in the discord or wait until someone make a guide.
Fixed bug with range of particle lights was dependent from field of view.
Fixed vanilla god rays for iNumSplits=3 (default is 2) parameter of SkyrimPrefs.ini,
which is number of shadow cascades. Now possible to have higher quality longer range shadows.
Fixed eyes and some transparent hairs for complex particle lights.
Added ReflectionCubemapInterior parameter to [WATER] category. Moved parallax parameters
to the enbseries.ini.
Fixed blending bug with some types of particle lights. Fixed game refraction bugs for glass
and added support of thickness adjusting of it as alpha channel of texture.
Optimized ExpandHDR performance for water.
Minor visual improvements to complex particle and fire lights.
Restored fix for transparent hairs in water reflections which looks green there.
Fixed size of complex particles when sky mesh is scaled. Removed shader caching
functionality as it not works because of some skse plugin or mod manager which
replaces file access functions. Applied minor cpu performance optimizations.
Fixed bug when skylighting makes terrain in some areas dark.
Added parameter EnableComplexMaterial because people are lazy to fix their mistakes.

Version 0.483
Added terrain blending effect. Improved performance of complex parallax.
Fixed game bug when some objects in water reflection have yellow-green color.
Added ability to load and replace decal textures inside the game to simplify their
editing, check profiler tab of editor window. Added depth bias for transparent
parallax meshes to avoid z-fighting. Complex parallax decals also can be made from
usual meshes to support their transparency.

Version 0.482
Added complex parallax effect for terrain, it adds two pass parallax occlusion mapping.
Added shadows for complex terrain parallax, from sun light and all point lights.

Version 0.481
Added complex parallax effect, it is disabled by default and replaces game one by
the two pass parallax occlusion mapping.
Added shadows for complex parallax, from sun light and all point lights, even those
not casting shadows.

Version 0.480
Added aurora borealis rendering to IBL effect. Changed reflective IBL to be the same as in Skyrim LE.
Made SpecularPowerMultiplier of complex grass dependent from global specular power of [ENVIRONMENT]
category. For [RAINWETSURFACES] and [WETSURFACES] categories added several specular related parameters
similar to Skyrim LE version.

Version 0.477
Fixed clouds shadow effect for close range objects with cubemaps and specular.
Added dropdown box support for shader variables, example for it added to the enbeffect.fx.
Added ExpandHDR parameter to the [WATER] category which is required if you are using sky
intensities over 25, but it may decrease performance on SLI or other multi gpu setups.
Added SpecularFromLight parameters similar to old Skyrim version. Increased precision
of some parameters ten times by request.
Added CubemapAmountMultiplier and CubemapCurve parameters to [ENVIRONMENT] category.
Reduced line transition bug some meters away from camera of skylighting effect.
Added new parameters to access in the ENB SDK, like weather and time.
Added SpecularPowerMultiplier parameter for complex grass. Reduced darkness following
camera of skylighting effect.

Version 0.475
Added grass collisions effect. Added shadows from point lights to the complex grass.
Replaced shadow bias for point and spot lights by own code to fix visibility of polygons.
Added UseOriginalUVAtlas parameter to the [RAIN] category which enable vanilla uv
coordinates for rain texture. Fixed bloom bug if RenderTarget1024 is used in the lens shader.
Increased maximal intensity limits for various parameters to 30000.
Disabled effects for custom game menu screens. Parameter IgnoreLoadingScreen also controls menu.
Added EnableInterior parameter for complex grass.
Fixed bug of FogAmountMultiplier not applied to water.
Fixed one waterfall shader not influenced by lighting parameters of [ENVIRONMENT] category.

Version 0.473
Removed original objects processing. Added lighting to the grass. Added complex grass
effect which use tangent space normal map in the bottom of diffuse map to draw grass
with sun lighting, subsurface scattering and specular. Specular amount is in alpha
channel of normal map. Subsurface scattering amount is in the left bottom corner of
normal map texture. Grass mesh must have vertex normals. Added category [COMPLEXGRASS]
and EnableComplexGrass parameter.
Added ApplyToSSS parameter to [SSAO_SSIL] category, it is superior and more correct
than Skyrim LE version. Renamed ApplyToAllGrass parameter to ApplyToBasicGrass.
Added BasicGrassFakeLight and FakeLight parameters for complex grass to satisfy
requests by users. Fixed complex grass direct lighting which game wrongly set different
to other objects per weather. Moved vertex colors of grass outside of ColorPow
computation, so landscape defined vertex colors now have less darkness. Little bit
improved cpu performance costs of complex grass.
Added optimization for Ryzen cpu of complex particles and complex grass which had
absurdly low performance by unknown reason.

Version 0.469
Added wireframe visualization to profiler category of editor. Allow negative values
for DirectLightingDesaturation and PointLightingDesaturation parameters.
Fixed color bugs when ColorPow parameter is above 2.0

Version 0.466
Added requested IgnoreWeatherSystemInterior parameters to simplify tweaking.
Added OptimizeSmallRange to complex particle and fire lights. When disabled,
small particles can be scaled up like in Skyrim LE version but at cost of performance.
Added LightingInfluence to the [SNOW] category. Added shadows to the snow particles.
Added depth bias to skylighting effect to reduce darkness of terrain when bDrawLandShadows=1
set. Potentially fixed clouds shadows always enabled if sky don't have any clouds layer with
custom weathers.

Version 0.465
Added separate ILMultiplierSSS and AOMultiplierSSS parameters for interiors.
Added [SNOW] category and game snow is now influenced by ambient and directional
light properties. Added LightParameters, TextureSunMask from enbsunsprite.fx to
enblens.fx shader. Applied cloud shadows effect to the snow.
Fixed cloud shadow on water. Increased performance of water displacement by
lowering texture lod for it. Fixed rain wet surfaces wrongly activated at snow.

Version 0.463
Fixed game subsurface scattering noise bug from point lights. Partially removed shader cache
optimization from version 0.440 because it makes terrain parallax not togglable if cache files
are not deleted. Added requested parameter IgnoreLoadingScreen to enblocal.ini.
Added SkyColorAmount to the [RAYS] category to fix difference between sun rays and sky color for
some presets. Raised upper limits of SkyColorAmount of [RAYS] and [VOLUMETRICRAYS] categories.
Fixed sun rays bug when intensity is applied twice making effect. Fixed bug when sky parameters
were not applied for volumetric and usual sun rays. Fixed weird colors when skylighting and
ambient occlusion are both enabled.
Partially fixed color issues with some mixing types of ambient occlusion caused by vertex colors
of the meshes. Made changes to point and spot shadows to reduce issues with window's shadow mods.
Added time of the day separation for CloudsEdgeMoonMultiplier parameter.
Fixed GUI scrolling bug after preset is reloaded.

Version 0.462
Added parallax fix and parallax terrain as optional parameter in [EFFECT] category.
Fixed eye shadow bug which appears with some eye mods.

Version 0.460
Added shadow quality parameter for directional light. Fixed bug in shadow of game point light
type. Sorted list of shaders in shader editor window according to their execution order.
Added EnableShadow and EnableVolumetricShadow parameters to [WATER] category similar to Skyrim LE.
Added quality parameter for water volumetric shadows. Increased quality of water shadows.
Added water lighting same as Skyrim LE version have. Fixed game water temporal antialiasing bug
with LDR clamping of values. Forced FXAA for the water. Fixed water amplitude not properly working
for some water types. Disabled shallow color for far distance water lod to make it fit regular water.
Added FresnelMin, FresnelMax, WetMultiplier parameters for water. Added cloud shadows for water.
Improved sun scattering of water. Improved water deepness calculation to fix refraction. Fixed
water reflection artifacts behind character. Fixed ssao/ssil dependency from field of view.

Version 0.454
Optimized CPU based performance of the mod. Fixed crashes with some overlay tools.
Added volumetric fog opacity parameter same as in old Skyrim.
Disabled mod for game menu and loading screen. May not work with some mods.

Version 0.452
Improved quality of screen space reflection. Forced it to be computed only for water
to avoid game visual bugs for non water objects, especially interiors. Added parameter
to disable reflections for interiors. Increased quality of ambient occlusion.
Added requested AOMultiplierSSS and ILMultiplierSSS parameters to adjust effect for bodies.
Disabled subsurface scattering effect for objects with rim lighting and no soft lighting
at same time. Fixed subdermal color cropping bug of subsurface scattering.
Added EnableSeparateInteriorParameters and BigRangeScaleInterior parameters to complex
fire and particle lights.

Version 0.448
Added screen space reflection effect as replacement of game one for better quality.
Fixed glitches of detailed shadow under grass. Lowest value of grass directional
and ambient parameters is decreased. Added QualityInterior to [REFLECTION] category.

Version 0.445
Added multipass support for enbeffect.fx shader. Added BloomSize variable to enbbloom.fx
and enbeffect.fx shaders. Increased deepness of detailed shadow to fix some issues.
Replaced enbbloom.fx shader by slower and higher quality version with tweakable parameters.

Version 0.440
Improved caching of shaders to reduce startup time, it is no more dependent from changes
made to preset. Highly recommended to use ShaderCache=true in your presets as it only
take long to compile in first run. Added SpecularPower parameter to complex particle and
fire lights. Fixed wrong colors of ssao interiors. Changed CausticAmount for underwater
to weather dependent. Disabled stars tweaking for water reflection to avoid weird bugs.

Version 0.437
Increased quality of detailed shadows. Added detailed shadows to several interior
light types. Increased precision of game shadows. Fixed black eyes bug caused
by detailed shadow effect. Added LightAmountMultiplier parameter to [EYE] category.
ILBrightnessCompression parameter is made time of the day dependent. Fixed flickering
shadows issue for some presets. Decreased time to compile shaders when press "apply changes"
button.

Version 0.435
Added normal mapping shadows effect for sun light, complex particle and fire lights.
Optimized performance a little of complex particles and fire lights. Added desaturation
parameter for game volumetric rays.

Version 0.427
Added EnableOldSSS parameter to [SUBSURFACESCATTERING] to mimic effect for Skyrim LE.
Fixed tint of hairs tweaked by ColorPow parameter. Fixed eyes when o riginal objects
processing is enabled. Added EnableCubemap parameter to RAINWETSURFACES category.
Added one more water type processing to fix sharp edges with puddles which do use
the same water. Added ILBrightnessCompression parameter to [SSAO_SSIL] category to
make indirect lighting for darker areas more intense.

Version 0.426
Decreased loading time of multiple weathers presets. Decreased loading time for full screen game
mode. Fixed bug with editor circle stuck on weather's change. Increased number of weatherID from 100 to 500.

Version 0.423
Added int UIHidden=1 annotation support to parameters of shaders to not display them in editor,
but access via enbseries sdk. Fixed not working DirectLightingColorFilterAmount parameter.
Fixed ambient not worked properly when clouds shadow is active.

Version 0.421
Added ScreenshotFormat parameter to enblocal.ini to switch bmp, png and jpg files.
Added HighResolutionScaling parameter to enblocal.ini for increasing size of editor
if using very high resolutions. Added SurfaceBrightness parameters to [SUBSURFACESCATTERING].
Fixed slices bug (holes) of game screen space reflection of the water. Fixed black areas
of wet surfaces effect when cubemap enabled and some mods installed which render negative
color of object to cubemap.

Version 0.417
AmbientLightingDesaturation is changed to support negative values to mimic curve parameter
from old skyrim for free by performance. Added Brightness parameter to [WATER] category.

Version 0.415
Added wet surfaces and rain wet surfaces. This effect in SE do not have specular map
parameters because it's not rasterised like old Skyrim mod have.

Version 0.412
Increased quality of detailed shadows and shadow from point light sources. Added FieldOfView
parameter to shaders the same as old skyrim mod have.

Version 0.409
Added FogColorFilter and FogColorFilterAmount parameters to [ENVIRONMENT] category the same
as in old Skyrim version of the mod. Added EnableDistantShadowAtNight parameter to the
[SHADOW] category. Fixed specular on some hairs.

Version 0.408
Added MotionBluriness and Brightness parameters to rain and changed it code to make it less
flat looking.

Version 0.406
Increased quality of the sun rays. Fixed subsurface scattering of characters when in cloud shadows.
Increased maximal amount of cloud shadows to tweak effect without touching opacity of real clouds.
Added DisableWrongSkyMath parameter to [SKY] category, same as old Skyrim mod have.

Version 0.401
Added color filter for volumetric fog and directional skylighting effect mode.

Version 0.396
Added enbunderwater.fx external shader and enbunderwaternoise.bmp to apply various distortions.
Aded DisableGameDOF parameter to enblocal.ini. Fixed potential bug which may lead to crash.

Version 0.395
Added underwater caustics effect, which require ENBHelperSE.dll plugin installed.

Version 0.394
Added sun rays effect similar to old Skyrim version. Fixed flickering when weather changes
if multiple weather system is enabled. Added code to skip processing of inventory objects.

Version 0.390
Added compatibility with latest game patch. Increased number of techniques from 128 to 2048
and number of textures from 64 to 128.

Version 0.386
Added unhandled water shader which to allow mods like Realistic Water Two to mix different
water types. Removed dependency of game wave amplitude on to tessellation, because it
is not controllable by the game anyway.

Version 0.383
Fixed incompatibility with some presets by forcing day and night exterior values for interiors.
Added wind blow particles for snowy places to [particle] category with lighting influence.
Modified water shader for underwater side of surface. Added palette bitmap support.

Version 0.381
Added tessellation displacement for some water types and water temporal antialiasing.
Added fresnel for water and disabling far distance reflection of the game.
Added range factor for game volumetric rays. Fixed issue when water do not receive
volumetric rays. Added LightingInfluence parameter for some particles.

Version 0.380
Added ColorPow parameter. Removed fake specular from water and added mudness parameter.

Version 0.379
Added water displacement, parallax, sun scattering effects for some waters.

Version 0.378
Added water caustic and dispersion effects.

Version 0.376
Added grass parameters to control instanced grass objects.

Version 0.374
Added expernal enbsunsprite.fx shader similar to old Skyrim mod version. Added interior
setting for subsurface scattering effect.

Version 0.373
Added volumetric sun rays same as in old Skyrim version of the mod, renamed previous
volumetric rays category to [GAMEVOLUMETRICRAYS].

Version 0.372
Added detailed shadow effect for sun and some interior lights and various bug fixes.

Version 0.371
Added multiple weather support, which require SKSE plugin from here https://www.nexusmods.com/skyrimspecialedition/mods/23174/

Version 0.370
Added fix of specular for characters. Added normal map and sun direction to prepass shader.
Added ambient lighting desaturation parameter and fix for black hair parameter. Timer.z is
now frame number which cyclically wraps to 0 after 9999 frames passed.

Version 0.368
Added distant shadows. Scaled clouds shadow to make them applied to distant mountains
similar like in old skyrim mod. Fixed clouds shadow applied to subsurface scattering.

Version 0.365
Added shadows for complex particle and fire lights. Please be careful with enabling these
effects, because performance can degrade dramatically when many particles are spawned.

Version 0.363
Many internal fixes for better quality similar to old skyrim. This includes subsurface
scattering blending, clouds shadow, ssao/ssil. Removed dots on snow and black bug on
the snow when snow shader enabled in game video options and lighting intensity is big.

Version 0.362
Added complex particle lights, fire lights and skin specular effects.

Version 0.356
Added enbeffectprepass.fx shader which is similar to post pass, but executed before
enbdepthoffield.fx shader.

Version 0.352
Added skylighting effect. Added new type of ssao/ssil effect and increased it's
performance and quality of it's filter.

Version 0.347
Added shader caching to "enbcache" folder to reduce startup time. Can be turned off in
enblocal.ini. Cache is regenerated on any changes made to enblocal.ini or enbseries.ini.
Do not share cache folder with presets.

Version 0.345
Added point light parameters to [ENVIRONMENT] category and game screen space reflection
parameters. Fixed subsurface scattering bugs, game water bug, decreased startup time.

Version 0.343
Added subsurface scattering same as in mod for old Skyrim. Increased performance.
Some minor bugfixes.

Version 0.341
Fixed game shaders to remove limitation of ldr, i didn't notice earlier that game is
forcing ldr. Changed code of animated stars, they use alpha channel to detect stars,
with new parameters fixing incompatibility with custom textures of stars and galaxy.
Added parameters to adjust intensity of game lens flare effect which look more intense
after recent removing of ldr limit.

Version 0.338
Added clouds edge parameters for [SKY] category from old Skyrim mod. Implemented backward
compatibility of all external shaders with VR optimized versions of them which will be
created in future via handling DynamicScaling parameter. Added animated stars parameter
and fixed game code which do not allow full darkness for stars and sky gradient.

Version 0.334
Increased performance in places with many objects visible in camera, these are CPU
optimizations, so they can be seen if you are not bottlenecked by videocard.
Added EnableDenosier parameter to ssao category, similar to old Skyrim mod.
Added edge antialiasing and two dithering types to enblocal.ini, removed dithering
parameter from enbseries.ini.

Version 0.331
Added DisableFakeLights parameter to enblocal.ini for switching on/off character light.
Added game ssao parameters for tweaking its amount and make it colorful. Some bug fixes.

Version 0.330
Added image based lighting effect from old Skyrim mod, fixed bug with clouds transition.
Disabled mod when Creation Kit is running. Added specular parameters for VEGETATION, EYE,
OBJECT categories and improved separation of such objects similar to old Skyrim mod.

Version 0.329
Added cloud shadows effect in its simplest form, few extra fog parameters and rain refraction
control.

Version 0.328
Added parameters for game volumetric rays, underwater and procedural sun.

Version 0.327
Added specular parameters to environment category and rain replacement. Tga rain
drops no longer supported, only dds, png and bmp. Added depth of field toggle hotkey.

Version 0.325
Added ssao/ssil effect. Original by the game is untouched.

Version 0.324
Added fix for reflection of trees in water as FixReflectionTrees parameter in enblocal.ini.
Added WINDOWLIGHT, LIGHTSPRITE, VOLUMETRICFOG, FIRE, PARTICLE parameters which mostly
similar to old Skyrim version, but not all objects yet handled and I'll keep searching
for missed.

Version 0.320
Added directional light parameters, aurora borealis, stars, clouds, sky gradient parameters.
Some compatibility fix for old AMD videocards.

Version 0.310
Added time of the day, interior and exterior detection. Fixed bug with not worked adaptation.
Added support of loading multiple plugins (.dllplugin extention) from "enbseries" folder.

Version 0.309
First version for Skyrim SE. Made all post processing shaders similar or equal to mod
for Fallout 4. Time of the day, interior and exterior separation, weather system are
not available yet. This version is mostly to remove original game post processing by
replacing it with custom from enbeffect.fx shader (untweaked, most code from old Skyrim
mod) or ReShade/SweetFX.




//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//INSTALL
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Extract files from folder Patch or WrapperVersion to your game folder, where game
execution file exist.



//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//PROBLEMS
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
If game crashing or work not as expected, make sure you are not running XFire, Afterburner,
EVGA, Steam overlay, screen and video capturing tools, GeForce Experience, Razer and Logitek
utils, other kind of tools and overlays (crapware). Antiviruses and various fake boosters
also may affect the mod.



//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//USED THIRD PARTY CODE/MIDDLEWARE AND THEIR LICENSES (THESE ARE NOT MOD LICENSES)
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Using dumped shader's information by Nukem9.


Using AntTweakBar
Copyright (C) 2005-2019 Philippe Decaudin
AntTweakBar web site: http://www.antisphere.com



Using 3Dmigoto
3Dmigoto authors: Chiri, Bo3b Johnson, Ulf Jalmgrant (AKA Flugan), Ian Munsie (AKA DarkStarSword)

The MIT License (MIT)

Copyright (c) 2014-2019 the 3Dmigoto project authors (see the file AUTHORS.txt
for a complete list)

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
http://enbdev.com
Copyright (c) 2007-2024 Vorontsov Boris (ENB developer)
